package cvut.fel.exception;

public class FieldTooLongException extends RuntimeException {
}
