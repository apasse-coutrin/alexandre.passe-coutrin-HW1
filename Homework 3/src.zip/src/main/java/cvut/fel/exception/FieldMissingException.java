package cvut.fel.exception;

public class FieldMissingException extends RuntimeException {

}
